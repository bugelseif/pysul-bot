#!/bin/bash

zip -r "bot-pysul.zip" * -x "bot-pysul.zip"